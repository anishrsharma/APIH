from django.contrib import admin
from .models import Slots

# Register your models here.

admin.site.register(Slots)

