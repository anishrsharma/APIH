$(document).ready(function () {


    $('#btn-logout').click(function(){
        window.location.href = "/login";
    });
    
})
